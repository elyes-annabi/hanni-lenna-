function ocrErrorHandler(err, req, res, next) {
    console.error('Erreur OCR:', err);
    if (err.code === 'ENOENT') return res.status(404).json({ error: 'Configuration OCR non trouvée', details: err.message });
    if (err.name === 'SyntaxError') return res.status(400).json({ error: 'JSON invalide', details: err.message });
    res.status(500).json({ error: 'Erreur interne OCR', details: err.message });
}

function globalErrorHandler(err, req, res, next) {
    console.error('Erreur serveur:', err);
    res.status(500).json({ success: false, error: 'Erreur interne du serveur', details: err.message });
}

module.exports = { ocrErrorHandler, globalErrorHandler };
