const { app, BrowserWindow } = require("electron");
const path = require("path");

// Import seulement l’app Express
const serverApp = require("./index.js");

let mainWindow;
let backend;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Charger ton frontend (ton index.html Express)
  mainWindow.loadURL("http://localhost:3000/");
  mainWindow.webContents.openDevTools(); 

}

app.whenReady().then(() => {
  // Ici on démarre vraiment le serveur
  backend = serverApp.listen(3000, () => {
    console.log("🚀 Backend démarré sur http://localhost:3000");
    createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    if (backend) backend.close();
    app.quit();
  }
});