const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

// Routes
const profilesRouter = require('./routes/profiles');
const ocrRouter = require('./routes/ocr');
const scannersRouter = require('./routes/scanners');
const patchRouter = require('./routes/patch');
const processFileRouter = require('./routes/processFile');
const scanRouter = require('./routes/scan');




// Swagger
const { swaggerUi, specs, swaggerOptions } = require('./config/swagger');

// Middlewares
const { ocrErrorHandler, globalErrorHandler } = require('./middlewares/errorHandler');

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static('public'));

// ------------------- ROUTES -------------------
app.use('/profiles', profilesRouter);
app.use('/api/profile/ocr', ocrRouter);
app.use('/scanners', scannersRouter);
app.use('/patch', patchRouter);
app.use('/processFile', processFileRouter);
app.use('/api/scan', scanRouter); // correspond exactement à ton front
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs, swaggerOptions));

// Page principale
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route health
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: '1.0.0',
        features: {
            profiles: true,
            ocr: true,
            ocrPatch: true,
            scanners: true,
            patch: true
        }
    });
});

// ------------------- MIDDLEWARES -------------------
// Gestion d’erreurs spécifique OCR
app.use('/api/profile/ocr', ocrErrorHandler);

// Gestion d’erreurs globale
app.use(globalErrorHandler);

// 404
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Route non trouvée',
        path: req.path,
        method: req.method
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Serveur démarré sur le port ${PORT}`);
});

module.exports = app;
