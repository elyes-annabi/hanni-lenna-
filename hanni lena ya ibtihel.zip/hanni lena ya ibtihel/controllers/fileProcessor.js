// controllers/fileController.js
const fileService = require('../services/fileService');

exports.processFile = async (req, res) => {
    
    try {
        await fileService.processFile(req, res);
    } catch (err) {
        console.error("❌ Erreur processFile:", err);
        res.status(500).json({ 
            error: "Erreur lors du traitement du fichier", 
            details: err.message 
        });
    }
};

exports.generatePatchOnly = async (req, res) => {
    try {
        await fileService.generatePatchOnly(req, res);
    } catch (err) {
        console.error("❌ Erreur génération patch:", err);
        res.status(500).json({ 
            error: "Erreur lors de la génération du patch", 
            details: err.message 
        });
    }
};
