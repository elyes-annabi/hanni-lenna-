const express = require("express");
const multer = require("multer");
const router = express.Router();
const fileProcessor = require("../controllers/fileProcessor"); // import corrigé

const upload = multer({ dest: "uploads/" });

/**
 * @swagger
 * tags:
 *   name: File Processing
 *   description: Traitement et analyse de fichiers
 */

/**
 * @swagger
 * /processFile:
 *   post:
 *     summary: Traitement et analyse d'un fichier uploadé
 *     tags: [File Processing]
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - file
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: Fichier à traiter (PDF, image, etc.)
 *               options:
 *                 type: string
 *                 description: Options de traitement en JSON
 *                 example: '{"lang":"fra","ocr":true,"format":"pdf"}'
 *               profile:
 *                 type: string
 *                 description: Nom du profil de traitement à utiliser
 *                 example: "default"
 *     responses:
 *       200:
 *         description: Fichier traité avec succès
 *       400:
 *         description: Fichier manquant ou invalide
 *       415:
 *         description: Type de fichier non supporté
 *       500:
 *         description: Erreur lors du traitement
 */
router.post("/", upload.single("file"), fileProcessor.processFile);

module.exports = router;
