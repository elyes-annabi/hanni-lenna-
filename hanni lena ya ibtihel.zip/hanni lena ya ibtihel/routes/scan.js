const express = require('express');
const path = require('path');
const router = express.Router();

// Import du contrôleur
const { processFile } = require('../controllers/fileProcessor');

// Route scan normal
router.post('/', async (req, res) => {
    try {
        const { profileName, action } = req.body;
        if (!profileName || action !== 'scan') {
            return res.status(400).json({ success: false, error: 'Paramètres invalides' });
        }
        console.log(`📠 Scan déclenché pour le profil: ${profileName}`);
        // Retour simple (scan normal, pas encore patch)
        res.json({ success: true, message: `Scan démarré pour ${profileName}` });
    } catch (error) {
        console.error('Erreur scan:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Route scan + patch
router.post('/patch', async (req, res) => {
  try {
    const { filePath, ...config } = req.body;

    if (!filePath) {
      return res.status(400).json({ success: false, error: 'filePath manquant' });
    }

    // Simuler un fichier uploadé pour processFile
    req.file = { path: filePath, originalname: path.basename(filePath) };
    req.body = { ...config, scan: "false" }; // on ne refait pas le scan, juste patch

    // Appel du service de traitement
    return processFile(req, res);
  } catch (error) {
    console.error('Erreur scan/patch:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
