const express = require('express');
const router = express.Router();
const OcrConfigController = require('../controllers/ocrConfigController');
const ocrController = new OcrConfigController();
const { isValidPatchStrategy, strategies } = require('../utils/patchStrategies');

// Routes spécifiques Patch et utilitaires
router.get('/patch/strategies', async (req, res) => {
    try {
        res.json({ success: true, strategies, count: strategies.length });
    } catch (error) {
        res.status(500).json({ error: 'Erreur serveur', details: error.message });
    }
});

router.post('/validate', async (req, res) => {
    try {
        const config = req.body;
        const errors = [];
        const warnings = [];
        if (!config) return res.status(400).json({ error: 'Configuration manquante' });

        if (config.lang && !['', 'fra', 'eng', 'ara'].includes(config.lang)) warnings.push(`Langue OCR "${config.lang}" non standard`);
        if (config.pdfMode && !['pdf','pdfa'].includes(config.pdfMode)) errors.push(`Mode PDF "${config.pdfMode}" invalide`);
        if (config.patchNaming && !isValidPatchStrategy(config.patchNaming)) errors.push(`Stratégie Patch "${config.patchNaming}" invalide`);
        if (config.patchMode === true && !config.patchNaming) warnings.push('Mode Patch activé mais aucune stratégie de nommage définie');
        if (config.ocrMode === false && config.patchMode === true) warnings.push('Mode Patch activé sans OCR peut limiter les options de nommage');

        res.json({ isValid: errors.length === 0, errors, warnings, validatedConfig: config });
    } catch (error) {
        res.status(500).json({ error: 'Erreur serveur', details: error.message });
    }
});

//router.post('/migrate-all', ocrController.migrateAll.bind(ocrController));
//router.get('/report', ocrController.generateReport.bind(ocrController));
//router.get('/test', ocrController.testConfig.bind(ocrController));

// Routes OCR CRUD
router.post('/', ocrController.saveOcrConfig.bind(ocrController));
router.get('/', ocrController.getAllOcrConfigs.bind(ocrController));
router.get('/:profileName', ocrController.getOcrConfig.bind(ocrController));
router.delete('/:profileName', ocrController.deleteOcrConfig.bind(ocrController));

module.exports = router;
