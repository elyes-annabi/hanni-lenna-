const express = require("express");
const patchService = require("../services/patchService");
const router = express.Router();
const fileProcessor = require("../controllers/fileProcessor"); // import corrigé

/**
 * @swagger
 * tags:
 *   name: Patch
 *   description: Gestion des patches et découpage de PDF
 */

/**
 * @swagger
 * /patch/split:
 *   post:
 *     summary: Découpage d'un PDF par patch
 *     tags: [Patch]
 */
router.post("/split", async (req, res) => {
  try {
    const { pdfPath, patchMode, lang, naming, namingPattern, ocrMode, containsPatch } = req.body;
    if (!pdfPath) return res.status(400).send("pdfPath est obligatoire");

    const results = await patchService.splitByPatch(pdfPath, {
      patchMode,
      lang,
      naming,
      namingPattern,
      ocrMode: ocrMode === 'true',
      containsPatch: containsPatch === 'true'
    });

    res.json({ success: true, results });
  } catch (err) {
    console.error("Erreur split:", err);
    res.status(500).json({ success: false, message: "Erreur split: " + err.message });
  }
});

/**
 * @swagger
 * /patch/generatePatch:
 *   post:
 *     summary: Génération de patch uniquement
 *     tags: [Patch]
 */
router.post('/generatePatch', fileProcessor.generatePatchOnly);

module.exports = router;
