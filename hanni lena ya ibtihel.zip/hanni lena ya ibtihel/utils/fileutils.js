const fs = require("fs");
const path = require("path");

function cleanUploadsFolder() {
  const uploadsPath = path.join(__dirname, "../uploads");
  if (!fs.existsSync(uploadsPath)) return;
  fs.readdirSync(uploadsPath).forEach(file => fs.unlinkSync(path.join(uploadsPath, file)));
}

function applyNamingPattern(filePath, pattern, index = 1) {
  const ext = path.extname(filePath);
  const nameWithoutExt = path.basename(filePath, ext);
  const now = new Date();
  const YYYY = now.getFullYear();
  const MM = String(now.getMonth() + 1).padStart(2, "0");
  const DD = String(now.getDate()).padStart(2, "0");
  const n = index.toString().padStart(2, "0");

  return `${nameWithoutExt}${pattern.replace(/\$\((YYYY)\)/g, YYYY).replace(/\$\((MM)\)/g, MM).replace(/\$\((DD)\)/g, DD).replace(/\$\((n)\)/g, n)}${ext}`;
}

module.exports = { cleanUploadsFolder, applyNamingPattern };
