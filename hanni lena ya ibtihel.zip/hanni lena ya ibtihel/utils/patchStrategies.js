const strategies = [
    { value: 'barcode_ocr_generic', label: 'Code-barres → OCR → Générique (Recommandé)', description: 'Essaie code-barres puis OCR puis générique', priority: 1, recommended: true },
    { value: 'barcode', label: 'Code-barres uniquement', description: 'Nommer uniquement via codes-barres', priority: 2, recommended: false },
    { value: 'ocr', label: 'OCR de texte uniquement', description: 'Nommer uniquement via OCR', priority: 3, recommended: false },
    { value: 'generic', label: 'Nommage générique simple', description: 'Nom basé sur date/heure', priority: 4, recommended: false }
];

function isValidPatchStrategy(strategy) {
    return strategies.some(s => s.value === strategy);
}

module.exports = { strategies, isValidPatchStrategy };
