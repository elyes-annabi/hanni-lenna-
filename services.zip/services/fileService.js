// services/fileService.js
const path = require("path");
const fs = require("fs");
const sharp = require("sharp");
const { PDFDocument } = require("pdf-lib");

const pdfService = require("./pdfService");
const ocrPdfService = require("./ocrPdfService");
const ocrService = require("./ocrService");
const langDetect = require("./langDetect");
const pdfImageExtractor = require("./pdfImageExtractor");
const patchService = require("./patchService");
const scanService = require("./scanService");
const { applyNamingPattern, cleanUploadsFolder } = require("../utils/fileutils");
const tempFiles = [];

// --- Validation PDF ---
async function validatePDF(filePath) {
  try {
    const buffer = fs.readFileSync(filePath);
    if (buffer.length < 1000) throw new Error("Fichier PDF trop petit ou vide");
    const header = buffer.slice(0, 5).toString();
    if (!header.startsWith("%PDF")) throw new Error("Fichier PDF invalide");
    await PDFDocument.load(buffer, { ignoreEncryption: true, throwOnInvalidObject: false });
    return true;
  } catch (error) {
    throw new Error(`PDF invalide ou corrompu: ${error.message}`);
  }
}

// --- Process File ---
async function processFile(req, res) {
  let filePath, fileName;
  const ocrMode = req.body.ocrMode !== "false"; // true par défaut
  console.log("===== REQUÊTE REÇUE =====");
  console.log("Body :", req.body);
  console.log("Fichier :", req.file); // si upload
  console.log("==========================");
  try {
    let pdfBlocks = [];
    const outputDir = req.body.outputDir || path.join(__dirname, "../output");
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

    // ------------- SCAN -------------
    if (req.body.scan === "true") {
      if (!req.body.profileName) {
        return res.status(400).json({ error: "Le paramètre 'profileName' est requis pour effectuer un scan" });
      }

      try {
        const scanResult = await scanService.scanFile(req.body.profileName, outputDir);

        if (typeof scanResult === "string" && fs.existsSync(scanResult)) {
          filePath = scanResult;
          fileName = path.basename(filePath);

          try {
            await validatePDF(filePath);
          } catch (validationError) {
            return res.status(500).json({
              error: "Le fichier scanné est corrompu ou invalide",
              details: validationError.message
            });
          }

        } else {
          return res.status(500).json({ error: "Erreur lors du scan - structure de retour invalide" });
        }
      } catch (scanError) {
        return res.status(500).json({
          error: "Erreur lors du scan",
          details: scanError.message,
          suggestions: [
            "Vérifiez que le scanner est connecté et allumé",
            "Vérifiez que le profil existe dans la configuration",
            "Assurez-vous que NAPS2 est correctement installé",
            "Vérifiez les permissions d'écriture dans le dossier de sortie"
          ]
        });
      }

    } else if (req.file) {
      filePath = req.file.path;
      fileName = req.file.originalname;
    } else {
      return res.status(400).json({ error: "Aucun fichier reçu et mode scan non activé." });
    }

    const ext = path.extname(fileName).toLowerCase();

    // ------------- PDF -------------
    if (ext === ".pdf") {
      try {
        await validatePDF(filePath);
        const hasText = await pdfService.extractText(filePath);
        let lang = req.body.lang;

        if (!lang || lang.length < 2) {
          if (hasText && hasText.trim().length > 0) {
            lang = langDetect.detectLang(hasText.trim().slice(0, 1000)) || "eng";
          } else {
            let quickText = "";
            const pagesForLangDetection = 3;
            const totalPages = await pdfService.getPageCount(filePath);
            for (let i = 0; i < Math.min(pagesForLangDetection, totalPages); i++) {
              try {
                const imagePath = await pdfImageExtractor.extractPageAsImage(filePath, i + 1);
                tempFiles.push(imagePath);
                const pageText = await ocrService.ocrImage(imagePath);
                if (pageText) quickText += pageText + "\n";
              } catch (pageError) {
                console.warn(`⚠️ Erreur extraction page ${i + 1}:`, pageError.message);
              }
            }
            lang = langDetect.detectLang(quickText || "") || "eng";
          }
        }

        const containsPatch = req.body.containsPatch === "true";
        const patchMode = req.body.patchMode || "T_classique";
        const naming = req.body.naming || "generic";
        const namingPattern = req.body.namingPattern;

        pdfBlocks = [filePath];

        if (containsPatch) {
          const patchOptions = { patchMode, lang, naming, namingPattern, ocrMode, containsPatch: true };
          try {
            pdfBlocks = await patchService.splitByPatch(filePath, patchOptions, outputDir);
            tempFiles.push(...pdfBlocks.map(f => (typeof f === "string" ? f : f.file)));
          } catch (patchError) {
            return res.status(500).json({ error: "Erreur lors de la division par patch", details: patchError.message });
          }
        }

        // ---------- OCR / téléchargement ----------
        if (!ocrMode) {
          if (containsPatch) {
            const filesInfo = pdfBlocks.map((f, index) => {
              const fPath = typeof f === "string" ? f : f.file;
              let finalName = path.basename(fPath);
              if (namingPattern && typeof f === "object") {
                finalName = applyNamingPattern(finalName, namingPattern, index + 1);
              }
              return {
                name: finalName,
                content: fs.readFileSync(fPath).toString("base64"),
                pages: f.pages || [],
                barcode: f.barcode || null
              };
            });
            return res.json({ status: "success", message: "PDF découpés par blocs (mode patch sans OCR)", files: filesInfo });
          } else {
            return res.download(pdfBlocks[0], path.basename(pdfBlocks[0]));
          }
        } else {
          const filesInfo = [];
          for (const [blockIndex, pdfBlock] of pdfBlocks.entries()) {
            const blockPath = typeof pdfBlock === "string" ? pdfBlock : pdfBlock.file;
            if (!blockPath || !fs.existsSync(blockPath)) continue;

            try {
              let ocrPath = await ocrPdfService.ocrPdfFile(blockPath, lang, outputDir, {
  modeOcr: req.body.modeOcr || "auto",
  pdfMode: req.body.pdfMode || "pdf",
  dpi: req.body.dpi || 150
});


              if (namingPattern) {
                const renamedFile = applyNamingPattern(path.basename(ocrPath), namingPattern, blockIndex + 1);
                const renamedPath = path.join(path.dirname(ocrPath), renamedFile);
                if (fs.existsSync(ocrPath)) fs.renameSync(ocrPath, renamedPath);
                ocrPath = renamedPath;
              }

              const fileBuffer = fs.readFileSync(ocrPath);
              const base64Content = fileBuffer.toString("base64");

              filesInfo.push({
                name: path.basename(ocrPath),
                content: base64Content,
                pages: typeof pdfBlock === "object" ? pdfBlock.pages || [] : [],
                barcode: typeof pdfBlock === "object" ? pdfBlock.barcode || null : null
              });

              tempFiles.push(ocrPath);
            } catch (ocrError) {
              return res.status(500).json({ error: `Erreur OCR bloc ${blockIndex + 1}`, details: ocrError.message });
            }
          }

          // Nettoyage des temporaires
          tempFiles.forEach(f => {
            const fPath = typeof f === "string" ? f : f.path;
            try {
              if (fs.existsSync(fPath) && !filesInfo.find(info => info.name === path.basename(fPath))) fs.unlinkSync(fPath);
            } catch {}
          });

          if (containsPatch || filesInfo.length > 1) {
            return res.json({
              status: "success",
              message: `${containsPatch ? "PDF découpés par blocs et " : ""}OCRisés avec succès`,
              files: filesInfo
            });
          } else {
            const tempPath = path.join(outputDir, filesInfo[0].name);
            fs.writeFileSync(tempPath, Buffer.from(filesInfo[0].content, "base64"));
            return res.download(tempPath, filesInfo[0].name, () => { try { fs.unlinkSync(tempPath); } catch {} });
          }
        }
      } catch (pdfProcessError) {
        return res.status(500).json({
          error: "Erreur lors du traitement du PDF",
          details: pdfProcessError.message,
          suggestions: [
            "Vérifiez que le fichier PDF n'est pas corrompu",
            "Essayez avec un fichier PDF plus simple",
            "Vérifiez l'espace disque disponible",
            "Redémarrez l'application si le problème persiste"
          ]
        });
      }

    } else if ([".jpg", ".jpeg", ".png", ".tiff", ".tif"].includes(ext)) {
      // ---------- IMAGE ----------
      try {
        let lang = req.body.lang;
        if (!lang) {
          const ocrText = await ocrService.ocrImage(filePath);
          lang = langDetect.detectLang(ocrText || "") || "eng";
        }

        const cleanImagePath = path.join(outputDir, fileName);
        await sharp(filePath).removeAlpha().toFile(cleanImagePath);

        let finalPdf = await ocrPdfService.imageToPdf(cleanImagePath, lang, outputDir);
        if (req.body.namingPattern) {
          const renamedFile = applyNamingPattern(path.basename(finalPdf), req.body.namingPattern, 1);
          const renamedPath = path.join(path.dirname(finalPdf), renamedFile);
          if (fs.existsSync(finalPdf)) fs.renameSync(finalPdf, renamedPath);
          finalPdf = renamedPath;
        }

        cleanUploadsFolder();
        return res.download(finalPdf, path.basename(finalPdf));
      } catch (imageError) {
        return res.status(500).json({ error: "Erreur lors du traitement de l'image", details: imageError.message });
      }
    } else {
      return res.status(400).json({ error: "Type de fichier non supporté", supportedFormats: [".pdf", ".jpg", ".jpeg", ".png", ".tiff", ".tif"] });
    }

  } catch (err) {
    // Nettoyage temporaire
    tempFiles.forEach(f => {
      const fPath = typeof f === "string" ? f : f.path;
      try { if (fs.existsSync(fPath)) fs.unlinkSync(fPath); } catch {}
    });

    return res.status(500).json({
      error: "Erreur lors du traitement du fichier",
      details: err.message,
      timestamp: new Date().toISOString(),
      suggestions: [
        "Vérifiez que tous les services requis sont démarrés",
        "Vérifiez l'espace disque disponible",
        "Essayez avec un fichier plus petit",
        "Contactez l'administrateur si le problème persiste"
      ]
    });
  }
}

// --- Génération patch uniquement ---
async function generatePatchOnly(req, res) {
  try {
    const { patchData } = req.body;
    if (!patchData) return res.status(400).json({ error: "Le paramètre 'patchData' est requis pour générer un patch" });

    const templatePath = path.join(__dirname, "..", "patchT", "patchT_template.png");
    if (!fs.existsSync(templatePath)) return res.status(500).json({ error: "Template de patch non trouvé", path: templatePath });

    const result = await patchService.generatePatchFromData(patchData, templatePath);
    return res.json({ status: "success", message: "Patch généré avec succès", results: [result] });

  } catch (err) {
    return res.status(500).json({ error: "Erreur lors de la génération du patch", details: err.message });
  }
  
}

module.exports = { processFile, generatePatchOnly, validatePDF };
