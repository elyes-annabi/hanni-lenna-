const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

// 📌 Constantes globales
const exePath = path.join(__dirname, "..", "bin", "patchsplitter.exe");
const outputDir = path.join(__dirname, "../output");
const templatePath = path.join(__dirname, "..", "patchT", "patchT_template.png");

// Création du dossier output si manquant
if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

// Utilitaire pour lancer patchsplitter.exe
function spawnProcess(args) {
  return new Promise((resolve, reject) => {
    const child = spawn(exePath, args, { cwd: outputDir, stdio: ["ignore", "pipe", "pipe"] });

    let error = "";
    let stdout = "";

    child.stderr.on("data", d => error += d.toString());
    child.stdout.on("data", d => stdout += d.toString());

    child.on("close", code => {
      if (code !== 0) reject(new Error(`patchsplitter.exe failed (code ${code}): ${error}`));
      else resolve(stdout);
    });

    child.on("error", err => reject(new Error(`Impossible de lancer patchsplitter.exe: ${err.message}`)));
  });
}

// 🟢 Découpage PDF
exports.splitByPatch = async (pdfPath, options = {}) => {
  const pdfAbsolutePath = path.resolve(pdfPath);

  if (!fs.existsSync(templatePath)) throw new Error("Template introuvable : " + templatePath);
  if (!fs.existsSync(pdfAbsolutePath)) throw new Error("PDF introuvable : " + pdfAbsolutePath);

  const args = [
    "--pdf_path", pdfAbsolutePath,
    "--template_path", templatePath,
    "--mode", options.patchMode || "T_classique",
    "--lang", options.lang || "fra",
    "--naming", options.naming || "barcode_ocr_generic"
  ];

  await spawnProcess(args);

  const jsonFile = path.join(outputDir, "results.json");
  if (!fs.existsSync(jsonFile)) throw new Error("JSON de sortie introuvable : " + jsonFile);

  const files = JSON.parse(fs.readFileSync(jsonFile, "utf-8"));

  return files.map(f => ({
    ...f,
    file: path.join(outputDir, path.basename(f.file))
  }));
};

// 🟢 Génération de patch
exports.generatePatchFromData = async (data) => {
  const args = [
    "--template_path", templatePath,
    "--generate_patch",
    "--data", data
  ];

  const stdout = await spawnProcess(args);

  const fileMatch = stdout.match(/Patch généré\s*:\s*(.+?\.(pdf|png))/i);
  if (!fileMatch) throw new Error("Aucun fichier patch trouvé dans la sortie");

  const generatedPatch = fileMatch[1];
  if (!fs.existsSync(generatedPatch)) throw new Error("Fichier patch introuvable : " + generatedPatch);

  const destPath = path.join(outputDir, path.basename(generatedPatch));
  if (generatedPatch !== destPath) fs.copyFileSync(generatedPatch, destPath);

  const fileBuffer = fs.readFileSync(destPath);
  const base64Content = fileBuffer.toString("base64");
  const ext = path.extname(destPath).toLowerCase();
  const mimeType = ext === ".pdf" ? "application/pdf" : "image/png";

  return {
    name: path.basename(destPath),
    base64: base64Content,
    mimeType,
    path: destPath
  };
};
