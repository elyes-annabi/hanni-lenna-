const { execFile } = require("child_process");
const path = require("path");
const fs = require("fs");
const pdfParse = require("pdf-parse");

const ocrmypdfExe = path.join(__dirname, "..", "bin", "ocrmypdf_runner.exe"); 
const tesseractDir = path.resolve("bin/tesseract");
const ghostscriptDir = path.resolve("bin/ghostscript/gs10.05.1/bin");
const popplerDir = path.resolve("bin/poppler/library/bin");

// ---------------- Extraction texte PDF ----------------
exports.extractText = async (filePath) => {
  try {
    const buffer = fs.readFileSync(filePath);
    const data = await pdfParse(buffer);
    return data.text.trim();
  } catch (err) {
    console.error("❌ Erreur lecture PDF :", err);
    return "";
  }
};

// ---------------- OCR PDF ----------------
exports.ocrPdfFile = async (inputPath, lang = "eng", outputDir, options = {}) => {
  return new Promise((resolve, reject) => {
    const absoluteInputPath = path.resolve(inputPath);
    if (!outputDir) outputDir = path.dirname(inputPath);
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

    const outputPath = path.join(
      outputDir,
      path.basename(inputPath, path.extname(inputPath)) + "_ocr.pdf"
    );

    const dpi = options.dpi || 150;
    const modeOcr = options.modeOcr || "auto";  // auto, force, skip
    const pdfMode = options.pdfMode || "pdf";   // pdf ou pdfa
    const optimize = options.optimize || 1;
    const tesseractTimeout = options.tesseractTimeout;

    const env = {
      ...process.env,
      PATH: `${tesseractDir};${ghostscriptDir};${popplerDir};${process.env.PATH}`,
      TESSDATA_PREFIX: path.join(tesseractDir, "tessdata"),
    };

    const args = [
      absoluteInputPath,
      outputPath,
      "--lang", lang,
      "--dpi", dpi.toString(),
      "--mode-ocr", modeOcr,
      "--mode", pdfMode,
      "--optimize", optimize.toString()
    ];

    if (typeof tesseractTimeout !== "undefined") {
      args.push("--tesseract-timeout", tesseractTimeout.toString());
    }

    console.log("📎 Commande :", ocrmypdfExe, args.join(" "));

    execFile(ocrmypdfExe, args, { env }, (err, stdout, stderr) => {
      if (err) {
        console.error("❌ Erreur ocrmypdf :", stderr || err);
        return reject(stderr || err.message);
      }
      console.log("✅ PDF OCRisé créé :", outputPath);
      resolve(outputPath);
    });
  });
};


// ---------------- OCR Image -> PDF ----------------
exports.imageToPdf = (imagePath, lang = "eng", outputDir, options = {}) => {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(imagePath)) return reject(new Error("Fichier image introuvable"));

    const baseName = path.basename(imagePath, path.extname(imagePath));
    if (!outputDir) outputDir = path.dirname(imagePath);
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

    const outputPdf = path.join(outputDir, baseName + "_ocr.pdf");

    const env = {
      ...process.env,
      PATH: `${tesseractDir};${ghostscriptDir};${popplerDir};${process.env.PATH}`,
      TESSDATA_PREFIX: path.join(tesseractDir, "tessdata")
    };

    const args = [
      path.resolve(imagePath),
      outputPdf,
      "--lang", lang,
      "--mode-ocr", options.modeOcr || "auto",
      "--dpi", (options.dpi || 150).toString(),
      "--mode", options.pdfMode || "pdf"
    ];

    console.log("📎 Commande OCR Image :", ocrmypdfExe, args.join(" "));

    execFile(ocrmypdfExe, args, { env }, (err, stdout, stderr) => {
      if (err) {
        console.error("❌ Erreur ocrmypdf :", stderr || err);
        return reject(stderr || err.message);
      }
      resolve(outputPdf);
    });
  });
};

