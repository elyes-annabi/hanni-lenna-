const path = require("path");

module.exports = {
    PYTHON_PATH: path.join(__dirname, "../bin/python/python.exe")
};
